#ifndef BBUFF_H
#define BBUFF_H
#include <stdbool.h>


#define BUFFER_SIZE 10
//#define values[3]

void bbuff_init(void);//done
void candyQ_insert(void* item);//done
void* candyQ_extract(void);//done
_Bool Q_isempty(void); //done


#endif